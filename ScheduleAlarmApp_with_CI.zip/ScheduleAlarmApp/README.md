# Schedule Alarm App

A very small Android app that lets you pick a time, optional label, and (optionally) repeat daily.
It uses `AlarmManager.setAlarmClock(...)` so alarms fire reliably even with Doze.

## How to build the APK in Android Studio
1. Open Android Studio → **File → Open…** → select the `ScheduleAlarmApp` folder.
2. Wait for Gradle sync to finish.
3. Connect a phone or use a virtual device to **Run**; or build an APK:
   - **Build → Build Bundle(s) / APK(s) → Build APK(s)**
   - After it finishes, click the notification to find `app-debug.apk`.
4. Copy the APK to your phone and install (enable "Install unknown apps" if prompted).

## Notes
- On Android 13+, the app asks for **Notifications** permission the first time.
- On reboot, scheduled alarms will be restored.
- Exact repeating uses reschedule-on-fire to remain reliable.

## Build without Android Studio (GitHub Actions)
1. Create a **new GitHub repo**, then upload the whole `ScheduleAlarmApp` folder.
2. Go to the **Actions** tab, enable workflows if prompted.
3. Open the **Android APK** workflow run; when it finishes, download the **app-debug** artifact → `app-debug.apk`.
